User login:

username:admin
password:admin

username:AnaBanana
password:jazsembanana123

username:jan123
password:geslo321